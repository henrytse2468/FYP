package com.example.dog;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class info_day extends AppCompatActivity implements View.OnClickListener {
    private Button start_r2c2, start_orbi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_day);

        start_r2c2 = findViewById(R.id.btn_infoDay_start_r2c2);
        start_r2c2.setOnClickListener(this);

        start_orbi = findViewById(R.id.btn_infoDay_start_orbi);
        start_orbi.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view==start_r2c2){
            Intent intent = new Intent(this, info_day_use.class);
            intent.putExtra("wifi", "r2c2");
            startActivity(intent);
        }

        if(view==start_orbi){
            Intent intent = new Intent(this, info_day_use.class);
            intent.putExtra("wifi", "orbi");
            startActivity(intent);
        }
    }
}
