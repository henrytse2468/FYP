package com.example.dog;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class register_page extends AppCompatActivity implements View.OnClickListener {
    private String video_path = "/storage/emulated/0/Pictures/VID_CAPTURED.mp4";
    private Uri fileUri;
    private Button start, btn_home;
    private boolean isRecord = false;
    private SQLiteDatabase database;
    private Cursor cursor;
    private final String training_api = "http://sshop.tplinkdns.com:3380/runTrain.php";
    ActivityResultLauncher<Intent> videoActivityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        start = findViewById(R.id.btn_start);
        start.setOnClickListener(this);
        btn_home = findViewById(R.id.btn_home);
        btn_home.setOnClickListener(this);

        //get camera permission
        if(ContextCompat.checkSelfPermission(register_page.this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(register_page.this, new String[]{
                    Manifest.permission.CAMERA
            }, 101);
        }

//        videoActivityResultLauncher = registerForActivityResult(
//                new ActivityResultContracts.StartActivityForResult(),
//                new ActivityResultCallback<ActivityResult>() {
//                    @Override
//                    public void onActivityResult(ActivityResult result) {
//                        if (result.getResultCode() == Activity.RESULT_OK) {
//                            // There are no request codes
//                            Intent data = result.getData();
//                            // doSomeOperations();
//                        }
//                    }
//                });
    }

    @Override
    public void onClick(View view) {
        if(view == btn_home){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
        if(view == start){
            if(isRecord){
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
            else{
                File video_cap = new File(video_path);
                fileUri = FileProvider.getUriForFile(register_page.this,
                        "com.example.homefolder.example.provider",video_cap);

                Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
                intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 5);
                // videoActivityResultLauncher.launch(intent);
                startActivityForResult(intent, 100);

            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100){
            UUID uuid = UUID.randomUUID();
            Ssh_upload ssh_upload = new Ssh_upload(video_path, uuid);
            String message = ssh_upload.upload();
            Toast.makeText(this, ""+message, Toast.LENGTH_SHORT).show();

            // Intent intent = new Intent(this, video_stream.class);
            // startActivity(intent);
            start.setText("Finish");
            isRecord = true;
            insert2DB(uuid);
            post_training_api(uuid);
        }
    }

    private void insert2DB(UUID uuid){
        try {
            database = SQLiteDatabase.openDatabase("/data/data/com.example.dog/userDB", null,
                    SQLiteDatabase.CREATE_IF_NECESSARY);
            String sqlCommand = "Insert INTO user values ( ' " + uuid.toString() + " ')";
            database.execSQL(sqlCommand);

            cursor = database.rawQuery("SELECT * from user", null);
            if(cursor.getCount()>0){
                @SuppressLint("Range") String databaseContent = cursor.getString(cursor.getColumnIndex("userID"));
                Toast.makeText(this, databaseContent, Toast.LENGTH_SHORT).show();
            }
            database.close();
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // call server side to carry out face recognition training
    private void post_training_api(UUID uuid){
        StringRequest request = new StringRequest(Request.Method.POST, training_api,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(register_page.this, "connect success! "+ response.trim(), Toast.LENGTH_SHORT).show();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(register_page.this, "connect not success! "+ error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<String, String>();
                param.put("id",  uuid.toString());
                Log.v("register_page", ""+param);
                return param;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(register_page.this);
        request.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 60000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 60000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });

        requestQueue.add(request);

    }
}
