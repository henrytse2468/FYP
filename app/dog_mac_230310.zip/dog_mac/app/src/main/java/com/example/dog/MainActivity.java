package com.example.dog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button make_reserve, check_reserve, register;
    private Intent intent = null;
    private SQLiteDatabase database;
    private Cursor cursor;
    private boolean isRegister = false;
    private Bundle extras;
    private String userid;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        make_reserve = findViewById(R.id.btn_book);
        check_reserve = findViewById(R.id.btn_check);
        register = findViewById(R.id.btn_register);

        make_reserve.setOnClickListener(this);
        check_reserve.setOnClickListener(this);
        register.setOnClickListener(this);
        userid = getSharedPreferences("user", MODE_PRIVATE).getString("user_uuid", "null");

        //checkDB();
        checkUser();
        if(!isRegister){
            toast();
        }

    }

    @Override
    protected void onResume(){
        super.onResume();
        checkDB();
    }

    @Override
    public void onClick(View v) {
        if (v == make_reserve){
            if(isRegister){
                intent = new Intent(this, book_page.class);
                if(!userid.equals("null")){
                    intent.putExtra("uuid", userid);
                }else{
                    extras = getIntent().getExtras();
                    intent.putExtra("uuid", extras.getString("uuid"));
                }
                startActivity(intent);
            }
            else{
                toast();
            }
        }

        if (v == check_reserve){
            if(isRegister){
                intent = new Intent(this, check_page.class);
                intent.putExtra("uuid", userid);
                startActivity(intent);
            }
            else{
                toast();
            }

        }

        if (v == register){
            if(!isRegister){
                intent = new Intent(this, register_page.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "You have already registered", Toast.LENGTH_SHORT).show();
            }

        }

    }

    private void toast(){
        Toast.makeText(this, "Please register first", Toast.LENGTH_SHORT).show();
    }

    private void checkDB(){
//        try{
//            database = SQLiteDatabase.openDatabase("/data/data/com.example.dog/userDB", null,
//                    SQLiteDatabase.CREATE_IF_NECESSARY);
//            String sqlCommand = "CREATE TABLE IF NOT EXISTS user(" +
//                    "userID TEXT NOT NULL PRIMARY KEY) ";
//            database.execSQL(sqlCommand);
//            cursor = database.rawQuery("SELECT * from user", null);
//            if(cursor.getCount() > 0){
//                isRegister = true;
//            }
//            database.close();
//        } catch (Exception e){
//            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
//        }



//        try{
//            extras = getIntent().getExtras();
//            if(extras != null){
//                isRegister = true;
//            }
//        }catch (Exception e){
//            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
//        }
    }

    private void checkUser(){
        if(!userid.equals("null"))
            isRegister = true;
    }
}