package com.example.dog;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import io.socket.client.IO;
import io.socket.client.Socket;

public class info_day_use extends AppCompatActivity implements View.OnClickListener {
    private Button firm;
    private RadioGroup radioButtonGroup;
    private TextView wayPoint_text;

    private String video_path = "/storage/emulated/0/Pictures/VID_CAPTURED.mp4";
    private Uri fileUri;
    private final String training_api = "http://sshop.tplinkdns.com:3380/runTrain.php";
    private final String recogn_api = "http://sshop.tplinkdns.com:3380/runRecog.php";
    private UUID uuid = null;

    private String extra_String = null;
    private final String hi_r2c2 = "http://192.168.1.24:3000";
    private final String hi_orbi = "http://192.168.4.4:3000";

    private Socket mSocket = null;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_day_use);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);



        firm = findViewById(R.id.firm);
        firm.setOnClickListener(this);

        wayPoint_text = findViewById(R.id.wayPoints_text);
        wayPoint_text.setVisibility(View.INVISIBLE);

        try {
            get_wayPoint();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        radioButtonGroup = findViewById(R.id.radioGroup);

        Intent i = getIntent();
        Bundle b = i.getExtras();
        if(b!=null){
            this.extra_String = b.getString("wifi");
        }
        Toast.makeText(this, extra_String, Toast.LENGTH_SHORT).show();


        try {
            if(extra_String.matches("r2c2")){
                mSocket = IO.socket(hi_r2c2);
                //Toast.makeText(this, hi_r2c2, Toast.LENGTH_SHORT).show();
            } else if (extra_String.matches("orbi")){
                mSocket = IO.socket(hi_orbi);
            }



        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        mSocket.connect();
        //Toast.makeText(this, ""+mSocket.id(), Toast.LENGTH_SHORT).show();
        //get camera permission
        /*
        if(ContextCompat.checkSelfPermission(info_day_use.this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(info_day_use.this, new String[]{
                    Manifest.permission.CAMERA
            }, 100);
        }
         */

    }

    @Override
    public void onClick(View view) {
        if(view == firm){
            /*
            try {
                take_video();
            } catch (IOException e) {
                e.printStackTrace();
            }
             */
            int radioButtonID = radioButtonGroup.getCheckedRadioButtonId();
            if(radioButtonID<0){
                Toast.makeText(this, "plz check button "+radioButtonID, Toast.LENGTH_SHORT).show();
            }
            else{
                View radioButton = radioButtonGroup.findViewById(radioButtonID);
                int idx = radioButtonGroup.indexOfChild(radioButton);
                RadioButton r = (RadioButton) radioButtonGroup.getChildAt(idx);

                //String selectedtext = r.getText().toString();
                //Toast.makeText(this, ""+selectedtext, Toast.LENGTH_SHORT).show();

                connect_dog_api(idx);
            }
        }
    }

    private void get_wayPoint() throws IOException, JSONException {
        URL url = new URL("http://192.168.1.24:3000/requests");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setDoInput(true);
        con.setDoOutput(true);

        JSONObject js = new JSONObject();
        js.put("topic", "/navigate/waypoints/list");

        OutputStream os = con.getOutputStream();
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
        writer.write(js.toString());
        writer.flush();
        writer.close();
        os.close();

        con.setConnectTimeout(5000);
        con.setReadTimeout(5000);

        con.connect();
        //System.out.println(con.getResponseCode());
        //ok

        BufferedReader in = new BufferedReader( new InputStreamReader(con.getInputStream())  );
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        wayPoint_text.setText(content.toString());

        in.close();
        con.disconnect();

    }

    private void connect_dog_api(int index) {
        String content = wayPoint_text.getText().toString();
        {
            try {
                JSONArray json_array = new JSONArray(content);
                JSONObject wayPoint = null;
                wayPoint = json_array.getJSONObject(index);

                JSONObject oj = wayPoint.getJSONObject("position");

                mSocket.emit("/navigate/to/pose", oj);

                Toast.makeText(this, oj.toString(), Toast.LENGTH_SHORT).show();


            }  catch (JSONException e) {
                e.printStackTrace();
            } finally {

            }
        }




    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mSocket.disconnect();
        mSocket.close();
    }

    private void take_video() throws IOException {
        File video_cap = new File(video_path);
        if(video_cap.exists()){
            video_cap.delete();
        }

        fileUri = FileProvider.getUriForFile(info_day_use.this,
                "com.example.homefolder.example.provider",video_cap);

        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri);
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 5);
        startActivityForResult(intent, 100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {

            // Ssh_upload ssh_upload = new Ssh_upload(video_path);
            // String message = ssh_upload.upload();

            // uuid = ssh_upload.getUUID();

            // Toast.makeText(this, ""+message, Toast.LENGTH_SHORT).show();

            do_training();
        }
    }

    private void do_training(){
        if(uuid != null){
            post_training_api();
            //post_recogn_api();
            //Intent intent = new Intent(this, video_stream.class);
            //startActivity(intent);
        }
        else{
            Toast.makeText(this, "null uuid", Toast.LENGTH_SHORT).show();
        }


    }

    private void post_training_api(){
        StringRequest request = new StringRequest(Request.Method.POST, training_api,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(info_day_use.this, "connect success! "+ response.trim(), Toast.LENGTH_SHORT).show();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(info_day_use.this, "connect not success! "+ error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<String, String>();
                param.put("id",  uuid.toString());
                Log.v("info_day_use_page", ""+param);
                return param;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(info_day_use.this);
        request.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 60000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 60000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });

        requestQueue.add(request);

    }

    private void post_recogn_api(){
        StringRequest request = new StringRequest(Request.Method.POST, recogn_api,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(info_day_use.this, "connect success! "+ response.trim(), Toast.LENGTH_SHORT).show();
                    }
                },

                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(info_day_use.this, "connect not success! "+ error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> param = new HashMap<String, String>();
                param.put("id",  uuid.toString());
                Log.v("info_day_use_page", ""+param);
                return param;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(info_day_use.this);
        requestQueue.add(request);

    }

}
