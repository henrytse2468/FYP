// not using

package com.example.dog;

import android.os.Bundle;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

public class video_stream extends AppCompatActivity {
    VideoView stream;
    private final String url = "rtsp://sshop.tplinkdns.com:8554/outstream";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_stream);

        stream = (VideoView) findViewById(R.id.streamVie);

        stream.setVideoPath(url);
        stream.requestFocus();
        stream.start();
    }
}
