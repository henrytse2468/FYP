package com.example.dog;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Booking_delete {
    private String deleteBooking_api = "http://sshop.tplinkdns.com:3380/deleteUserBooking.php";
    private int rid = 0;
    private Context context = null;

    public Booking_delete(Context c, int id){
        context = c;
        rid = id;
    }
    public String delete() {
        try{
            StringRequest request = new StringRequest(Request.Method.POST, deleteBooking_api, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    Toast.makeText(context, response.toString(), Toast.LENGTH_SHORT).show();
                    Log.d("onResponse: ", response.toString());
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                    Log.d("onErrorResponse: ", error.getMessage());
                }
            }){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> param = new HashMap<String, String>();
                    param.put("rid", String.valueOf(rid));
                    return param;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(request);
            //finish();
            return "The booking is deleted.";
        }catch (Exception e){
            Log.d("Error message", e.getMessage());
            return e.getMessage();
        }
    }
    public int getReserveID(){ return rid;}
}
