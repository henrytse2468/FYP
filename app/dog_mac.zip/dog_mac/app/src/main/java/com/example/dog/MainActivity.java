package com.example.dog;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button make_reserve, check_reserve, register;
    private Intent intent = null;
    private SQLiteDatabase database;
    private Cursor cursor;
    private boolean isRegister = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);

        make_reserve = findViewById(R.id.btn_book);
        check_reserve = findViewById(R.id.btn_check);
        register = findViewById(R.id.btn_register);

        make_reserve.setOnClickListener(this);
        check_reserve.setOnClickListener(this);
        register.setOnClickListener(this);

        try{
            database = SQLiteDatabase.openDatabase("/data/data/com.example.dog/userDB", null,
                    SQLiteDatabase.CREATE_IF_NECESSARY);
            String sqlCommand = "CREATE TABLE IF NOT EXISTS user(" +
                    "userID TEXT NOT NULL PRIMARY KEY) ";
            database.execSQL(sqlCommand);
            cursor = database.rawQuery("SELECT * from user", null);
            if(cursor.getCount() > 0){
                isRegister = true;
            }
            database.close();
        } catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        if(!isRegister){
            toast();
        }

    }

    @Override
    public void onClick(View v) {
        if (v == make_reserve){
            if(isRegister){
                intent = new Intent(this, book_page.class);
                startActivity(intent);
            }
            else{
                toast();
            }
        }

        if (v == check_reserve){
            if(isRegister){
                intent = new Intent(this, check_page.class);
                startActivity(intent);
            }
            else{
                toast();
            }

        }

        if (v == register){
            if(!isRegister){
                intent = new Intent(this, register_page.class);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "You have already registered", Toast.LENGTH_SHORT).show();
            }

        }

    }

    private void toast(){
        Toast.makeText(this, "Please register first", Toast.LENGTH_SHORT).show();
    }
}