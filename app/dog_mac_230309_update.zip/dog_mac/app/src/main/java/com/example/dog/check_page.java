package com.example.dog;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
//import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class check_page extends AppCompatActivity implements View.OnClickListener {
    private Button home;
    private LinearLayout layout;

    private OkHttpClient client;
    private Response response;
    private RequestBody requestBody;
    private Request request;
    private String strJson;
    private String getBooking_api = "http://sshop.tplinkdns.com:3380/getUserBooking.php";
    //private String deleteBooking_api = "http://sshop.tplinkdns.com:3380/deleteUserBooking.php";
    private Context context;
//    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel);
        context = this;
//        progressDialog = new ProgressDialog(this);
//        progressDialog.setTitle("Please wait");
//        progressDialog.setCanceledOnTouchOutside(false);

        home = findViewById(R.id.btn_home);
        home.setOnClickListener(this);
        layout = findViewById(R.id.page_info);

//        progressDialog.show();
        client = new OkHttpClient();
        new GetUserDataRequest().execute();
    }

    @Override
    public void onClick(View view) {
        if(view == home){
//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
//            Bundle extras = getIntent().getExtras();
//            Toast.makeText(check_page.this, extras.getString("uuid"), Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    // Get Data
    public class GetUserDataRequest extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {
            request = new Request.Builder().url(getBooking_api).build();

            try{
                response = client.newCall(request).execute();
            }catch (IOException e){
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void unused) {
            super.onPostExecute(unused);

            try{
                strJson = response.body().string();
                updateUserData(strJson);
            }catch (IOException e){
                e.printStackTrace();
            }
        }

        private void updateUserData(String strJson) {
            try{
                // Get uuid from main activity
                Bundle extras = getIntent().getExtras();
                String id = extras.getString("uuid");

                // JSON for get data from api
                JSONArray parent = new JSONArray(strJson);
                JSONObject child;
                String user_data = "";
                int count = 0;
                for(int i = 0; i < parent.length(); i++){
                    child = parent.getJSONObject(i);
                    if(child.getString("userID").equals(id)){

                        if(count!=0) user_data += "\n";

                        user_data += "ReserveID: " + child.getString("ReserveID") + "\n";
                        user_data += "Date-Time: " + child.getString("reserve_date") + " " + child.getString("start_time") + "\n";
                        user_data += "From: " + child.getString("start_point") + "\n";
                        user_data += "To: " + child.getString("destination");

                        // Create New TextView for a booking
                        TextView tv = new TextView(check_page.this);
                        LinearLayout.LayoutParams tvParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                        tvParams.setMargins(70, 30, 70, 0);
                        tv.setLayoutParams(tvParams);
                        tv.setTextSize(20);
                        tv.setText(user_data);
                        tv.setId(Integer.parseInt(child.getString("ReserveID")));
                        layout.addView(tv);
                        user_data = "";

                        // Create New Button for a booking
                        Button button = new Button(check_page.this);
                        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                        buttonParams.setMargins(70, 0, 70, 0);
                        button.setLayoutParams(buttonParams);
                        button.setText("Cancel Booking (ReserveID: " + child.getString("ReserveID") + ")");
                        button.setId(Integer.parseInt(child.getString("ReserveID")));
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                int id = v.getId();
                                //Toast.makeText(check_page.this, ""+id, Toast.LENGTH_SHORT).show();
                                DialogInterface.OnClickListener dialog = new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        switch (which){
                                            case DialogInterface.BUTTON_POSITIVE:
                                                //deleteBooking(id);
                                                Booking_delete booking_delete = new Booking_delete(context, id);
                                                String msg = booking_delete.delete();
                                                Toast.makeText(check_page.this, ""+msg, Toast.LENGTH_SHORT).show();
                                                finish();
                                                startActivity(getIntent());
                                                break;
                                            case DialogInterface.BUTTON_NEGATIVE:
                                                Toast.makeText(check_page.this, "The booking (ReserveID: " + id + ") did not cancel", Toast.LENGTH_SHORT).show();
                                                break;
                                        }
                                    }
                                };
                                AlertDialog.Builder builder = new AlertDialog.Builder(check_page.this);
                                builder.setMessage("Cancel Booking (ReserveID: " + id + ")?").setPositiveButton("Yes", dialog).setNegativeButton("No", dialog).show();
                            }
                        });
                        layout.addView(button);

//                        View view = new View(check_page.this);
//                        LinearLayout.LayoutParams viewParams = new LinearLayout.LayoutParams(350, 4);
//                        view.setLayoutParams(viewParams);
//                        view.setBackgroundColor(0x3d5e72);
//                        layout.addView(view);
                        count++;
                    }

                }
//                progressDialog.hide();

                //userData.setText(user_data);
            }catch (JSONException e){
                e.printStackTrace();
            }
        }
    }
}
