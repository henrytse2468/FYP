package com.example.dog;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import okhttp3.OkHttpClient;

public class book_page extends AppCompatActivity implements View.OnClickListener {
    private Button home, cancel, submit;
    private Spinner curSpinner, desSpinner;
    private RadioButton start_radio1, start_radio2, end_radio1, end_radio2;
    private EditText bookDate, bookTime, curClassRoom, desClassRoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_copy);

        start_radio1 = findViewById(R.id.start_radio1);
        start_radio1.setOnClickListener(this);
        start_radio2 = findViewById(R.id.start_radio2);
        start_radio2.setOnClickListener(this);
        end_radio1 = findViewById(R.id.end_radio1);
        end_radio1.setOnClickListener(this);
        end_radio2 = findViewById(R.id.end_radio2);
        end_radio2.setOnClickListener(this);

        home = findViewById(R.id.btn_home);
        home.setOnClickListener(this);

        cancel = findViewById(R.id.btn_formCancel);
        cancel.setOnClickListener(this);

        submit = findViewById(R.id.btn_fromSubmit);
        submit.setOnClickListener(this);

        bookDate = findViewById(R.id.bookDate);
        bookDate.setOnClickListener(this);
        bookDate.setFocusable(false);

        bookTime = findViewById(R.id.bookTime);
        bookTime.setOnClickListener(this);
        bookTime.setFocusable(false);

        curSpinner = (Spinner) findViewById(R.id.curSpinner);
        desSpinner = (Spinner) findViewById(R.id.desSpinner);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this
                ,R.array.loc_array,android.R.layout.simple_dropdown_item_1line);
        curSpinner.setAdapter(adapter);
        desSpinner.setAdapter(adapter);

        curClassRoom = findViewById(R.id.et_curClassrm);
        desClassRoom = findViewById(R.id.et_desClassrm);
    }

    @Override
    public void onClick(View view) {
        if(view == home || view == cancel){
//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
            finish();
        }

        if(view == bookDate){
            datePicker(view);
        }

        if(view == bookTime){
            timePicker(view);
        }

        if(view == submit){
            // insert to db
            if(start_radio2.isChecked() && isEmpty(curClassRoom))
                Toast.makeText(book_page.this, "Please enter the current classroom.", Toast.LENGTH_SHORT).show();
            else if(end_radio2.isChecked() && isEmpty(desClassRoom))
                Toast.makeText(book_page.this, "Please enter the destination.", Toast.LENGTH_SHORT).show();
            else if(bookTime.getText().toString().equals("HH:MM") || bookDate.getText().toString().equals("YYYY-MM-DD"))
                Toast.makeText(book_page.this, "Please select the date and time.", Toast.LENGTH_SHORT).show();
            else
                insert2DB();
        }


        // radios
        if(view == start_radio1){
            if(start_radio2.isChecked()){
                start_radio2.setChecked(false);
            }
        }
        if(view == start_radio2){
            if(start_radio1.isChecked()){
                start_radio1.setChecked(false);
            }
        }
        if(view == end_radio1){
            if(end_radio2.isChecked()){
                end_radio2.setChecked(false);
            }
        }
        if(view == end_radio2){
            if(end_radio1.isChecked()){
                end_radio1.setChecked(false);
            }
        }
    }

    public void datePicker(View v) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                // updated
                String datetime;
                if(month >= 9 && day >= 10)
                    datetime = String.valueOf(year) + "-" + String.valueOf(month+1) + "-" + String.valueOf(day);
                else if(month >= 9 && day < 10)
                    datetime = String.valueOf(year) + "-" + String.valueOf(month+1) + "-0" + String.valueOf(day);
                else if(month < 9 && day >= 10)
                    datetime = String.valueOf(year) + "-0" + String.valueOf(month+1) + "-" + String.valueOf(day);
                else
                    datetime = String.valueOf(year) + "-0" + String.valueOf(month+1) + "-0" + String.valueOf(day);
                bookDate.setText(datetime);
            }
        }, year, month, day).show();
    }

    public void timePicker(View v) {
        Calendar calendar = Calendar.getInstance();
        int hourOfDay = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);

        new TimePickerDialog(v.getContext(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String datetime;
                if(hourOfDay >= 10 && minute >= 10)
                    datetime = String.valueOf(hourOfDay) + ":" + String.valueOf(minute);
                else if(hourOfDay >= 10 && minute < 10)
                    datetime = String.valueOf(hourOfDay) + ":0" + String.valueOf(minute);
                else if(hourOfDay < 10 && minute >= 10)
                    datetime = "0" + String.valueOf(hourOfDay) + ":" + String.valueOf(minute);
                else
                    datetime = "0" + String.valueOf(hourOfDay) + ":0" + String.valueOf(minute);
                bookTime.setText(datetime);
            }
        }, hourOfDay, minute,true).show();
    }

    public boolean isEmpty(EditText text){
        return text.getText().toString().trim().length() == 0;
    }

    public void insert2DB(){
        try{
            // Get UUID
            final String id;
            Bundle extras = getIntent().getExtras();
            id = extras.getString("uuid");
            String startTime = bookTime.getText().toString() + ":00";
            String startLoca, endLoca;
            String bookingDate = bookDate.getText().toString();
            String booking_api = "http://sshop.tplinkdns.com:3380/insertBooking2.php";

            if(start_radio1.isChecked()){
                startLoca = curSpinner.getSelectedItem().toString();
            }else{
                startLoca = curClassRoom.getText().toString();
            }

            if(end_radio1.isChecked()){
                endLoca = desSpinner.getSelectedItem().toString();
            }else{
                endLoca = desClassRoom.getText().toString();
            }

            StringRequest request = new StringRequest(Request.Method.POST, booking_api, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    Toast.makeText(book_page.this, response.toString(), Toast.LENGTH_SHORT).show();
                    Log.d("onResponse: ", response.toString());
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(book_page.this, error.getMessage(), Toast.LENGTH_LONG).show();
                    Log.d("onErrorResponse: ", error.getMessage());
                }
            }){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> param = new HashMap<String, String>();
                    param.put("id", id);
                    param.put("start_time", startTime);
                    param.put("start_loc", startLoca);
                    param.put("destination", endLoca);
                    param.put("booking_date", bookingDate);
                    return param;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(book_page.this);
            requestQueue.add(request);
            finish();

        }catch(Exception e){
            Toast.makeText(book_page.this, "Fail", Toast.LENGTH_SHORT).show();
        }
    }
}
