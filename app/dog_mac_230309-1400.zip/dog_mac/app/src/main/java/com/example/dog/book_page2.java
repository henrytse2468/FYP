// not using

package com.example.dog;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class book_page2 extends AppCompatActivity implements View.OnClickListener {
    private Button home, cancel;
    private Spinner curSpinner, desSpinner;
    private EditText bookDate, bookTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        home = findViewById(R.id.btn_home);
        home.setOnClickListener(this);

        cancel = findViewById(R.id.btn_formCancel);
        cancel.setOnClickListener(this);

        bookDate = findViewById(R.id.bookDate);
        bookDate.setOnClickListener(this);
        bookDate.setFocusable(false);

        bookTime = findViewById(R.id.bookTime);
        bookTime.setOnClickListener(this);
        bookTime.setFocusable(false);

        curSpinner = (Spinner) findViewById(R.id.curSpinner);
        desSpinner = (Spinner) findViewById(R.id.desSpinner);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(this
                ,R.array.loc_array,android.R.layout.simple_dropdown_item_1line);
        curSpinner.setAdapter(adapter);
        desSpinner.setAdapter(adapter);
    }

    @Override
    public void onClick(View view) {
        if(view == home || view == cancel){
//            Intent intent = new Intent(this, MainActivity.class);
//            startActivity(intent);
            finish();
        }

        if(view == bookDate){
            datePicker(view);
        }

        if(view == bookTime){
            timePicker(view);
        }
    }

    public void datePicker(View v) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                String datetime = String.valueOf(year) + "-" + String.valueOf(month) + "-" + String.valueOf(day);
                bookDate.setText(datetime);
            }
        }, year, month, day).show();
    }


    public void timePicker(View v) {
        Calendar calendar = Calendar.getInstance();
        int hourOfDay = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);

        new TimePickerDialog(v.getContext(), new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String datetime = String.valueOf(hourOfDay) + ":" + String.valueOf(minute);
                bookTime.setText(datetime);
            }
        }, hourOfDay, minute,true).show();
    }

}
